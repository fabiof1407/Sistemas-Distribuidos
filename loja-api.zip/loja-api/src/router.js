const { Router } = require('express')
const { buscarProdutos } = require('../src/app/controller/lojaController')

const router = Router()

router.get('/loja', buscarProdutos)

module.exports = router