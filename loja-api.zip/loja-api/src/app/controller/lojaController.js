const axios = require('axios')

class LojaController {
    async buscarProdutos(request, response) {

        try{

        let array = []

        let res = await axios.get('https://fakestoreapi.com/products')
        
        res.data.forEach((resposta) => {
            array.push({
                "Loja": {
                    "titulo": resposta.title,
                    "descrição": resposta.description,
                    "categoria": resposta.category,
                    "preço": resposta.price,
                    "imagem": resposta.image    
                } 
            })  

        })    
        
        response.status(200).json(array)
        } catch (error){
            response.status(400).json(error)
        }

    }
    
}

module.exports = new LojaController()
